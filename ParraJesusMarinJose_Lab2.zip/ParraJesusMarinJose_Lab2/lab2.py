#-------------------------------------Interfaz-----------------------------------
from tkinter import ttk, Tk, Frame,Button 
import tkinter as tk
import pandas as pd
import matplotlib.pyplot as plot


from scipy import stats
import numpy  as np
from matplotlib.backends.backend_tkagg import (FigureCanvasTkAgg,  NavigationToolbar2Tk) 
from statistics import *
import scipy.stats as stats
from scipy.stats import kurtosis
main_window = tk.Tk()


from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score
from sklearn.metrics import mean_squared_error




archivo='abalone.csv'
datos=pd.read_csv(archivo)

#Insertamos las columnas de la tabla excel
columnas=['Sex', 'Length', 'Diameter', 'Height', 'Whole weight', 'Shucked weight',
'Viscera weight',
'Shell weight',
'Rings']
datos.columns=columnas

#------------------ HISTOGRAMA ------------------------------------------------
def Graficar1(datos, columna):
    ventana = Tk()
    ventana.geometry('990x325')
    ventana.wm_title('Graficas Matplotlib')
    ventana.minsize(width=950,height=325)
    
    frame = Frame(ventana,  bg='blue')
    frame.grid(column=0,row=0, sticky='nsew')
    
    fig, axs = plot.subplots(dpi=80, figsize=(13, 4),
    sharey=True, facecolor='#00f9f844')
    fig.suptitle(f'Historama de {columna}')
    axs.hist(datos[columna])
    canvas = FigureCanvasTkAgg(fig, master = frame)  # Crea el area de dibujo en Tkinter
    canvas.draw()
    canvas.get_tk_widget().grid(column=0, row=0)
    
    fig = plot.hist(datos[columna])
    plot.subplots()
    
def Graficar2(datos, columnas):
    ventana = Tk()
    ventana.geometry('990x325')
    ventana.wm_title('Graficas Matplotlib')
    ventana.minsize(width=950,height=325)
    
    frame = Frame(ventana,  bg='blue')
    frame.grid(column=0,row=0, sticky='nsew')
    
    fig, axs = plot.subplots(dpi=80, figsize=(13, 4),
    sharey=True, facecolor='#00f9f844')
    fig.suptitle(f'Cajas y bigotes de {columnas}')
    axs.boxplot(datos[columnas])
    canvas = FigureCanvasTkAgg(fig, master = frame)  # Crea el area de dibujo en Tkinter
    canvas.draw()
    canvas.get_tk_widget().grid(column=0, row=0)
    
    print("sex mode")
    plot.boxplot(datos[columnas])
    plot.subplots()
    
def Graficar3(datos, columnas):
    print("111")
    
    ventana = Tk()
    ventana.geometry('990x325')
    ventana.wm_title('Graficas Matplotlib')
    ventana.minsize(width=950,height=325)
    
    frame = Frame(ventana,  bg='blue')
    frame.grid(column=0,row=0, sticky='nsew')
    
    fig, axs = plot.subplots(dpi=80, figsize=(13, 4),
    sharey=True, facecolor='#00f9f844')
    aux = fig.add_subplot(111)
    res = stats.probplot(datos[columnas], dist = stats.norm, plot = aux)
    #s.boxplot(datos[columnas])
    
    
    canvas = FigureCanvasTkAgg(fig, master = frame)  # Crea el area de dibujo en Tkinter
    canvas.draw()
    canvas.get_tk_widget().grid(column=0, row=0)
    """
    fig= plot.figure()
    ax = fig.add_subplot(111)
    res = stats.probplot(datos[columnas], dist = stats.norm, plot = ax)
    plot.subplots()"""
    
def Graficar4(datos, columnas1, columna2):           
    ventana = Tk()
    ventana.geometry('990x325')
    ventana.wm_title('Graficas Matplotlib')
    ventana.minsize(width=950,height=325)
    
    frame = Frame(ventana,  bg='blue')
    frame.grid(column=0,row=0, sticky='nsew')
    
    fig, axs = plot.subplots(dpi=80, figsize=(13, 4),
    sharey=True, facecolor='#00f9f844')
    fig.suptitle(f'Historama de {columnas1} - {columna2}')
    axs.xcorr(datos[columnas1], datos[columna2])
    canvas = FigureCanvasTkAgg(fig, master = frame)  # Crea el area de dibujo en Tkinter
    canvas.draw()
    canvas.get_tk_widget().grid(column=0, row=0)
    
    fig = plot.xcorr(datos[columnas1], datos[columna2])
    plot.subplots()


#-------------------------Regresion Lineal-------------------------------------------

def Grafica5 (datos, columna1, columna2, columna3, columna4, columna5, columna6, columna7, columna8, salida):
    
    Length=datos['Length'].values
    Diameter=datos['Diameter'].values
    Height=datos['Height'].values
    WholeWeight= datos['Whole weight'].values
    shuckedWeight=datos['Shucked weight'].values
    visceraWeight = datos['Viscera weight'].values
    shellWeight=datos['Shell weight'].values
    rings=datos['Rings'].values
    
    X=np.array([Length,Diameter,Height,WholeWeight,shuckedWeight,visceraWeight,shellWeight,rings]).T()
    Y = datos[salida]
    
    modelo = LinearRegression()
    modelo.fit(X, Y)
    Y_pred=reg.predict(X)
    error=np.sqrt(mean_squared_error(Y,Y_pred))

    print('entrada longitud, salida anillos',modelo.score(np.array(X).reshape(-1, 1), Y))
    print('el valor del rmse es',rmse)
    
    ventana = Tk()
    ventana.geometry('990x325')
    ventana.wm_title('Graficas Matplotlib')
    ventana.minsize(width=950,height=325)
    frame = Frame(ventana,  bg='blue')
    frame.grid(column=0,row=0, sticky='nsew')
    fig, axs = plot.subplots(dpi=80, figsize=(13, 4),
    sharey=True, facecolor='#00f9f844')
    fig.suptitle(f'regresion lineal de {columna1},{columna2},{columna3},{columna4},{columna5},{columna6},{columna7},{columna8}')
    axs.hist(datos[columna1],datos[columna2], datos[columna3], datos[columna4], datos[columna5], datos[columna6],datos[columna7], datos[columna8])
    
    
    canvas = FigureCanvasTkAgg(fig, master = frame)  # Crea el area de dibujo en Tkinter
    canvas.draw()
    canvas.get_tk_widget().grid(column=0, row=0)
        
    fig = plot.hist(datos[columna1],datos[columna2], datos[columna3], datos[columna4], datos[columna5], datos[columna6],datos[columna7], datos[columna8])
    plot.subplots()


#---------------------------------Tabla estadistica--------------------------------------
def  Graficar6(datos):
    
    def datosEstadisticos(datos):
            lista_datos = []
            lista_datos.append(mean(datos))
            lista_datos.append(mode(datos))
            lista_datos.append(median(datos))
            lista_datos.append(stats.kurtosis(datos))
            lista_datos.append(stats.skew(datos))
            return lista_datos
        
        
    list_Length=datosEstadisticos(datos['Length'])
    list_Diameter=datosEstadisticos(datos['Diameter'])
    list_Height=datosEstadisticos(datos['Height'])
    list_Whole_weight=datosEstadisticos(datos['Whole weight'])
    list_Shucked_weight=datosEstadisticos(datos['Shucked weight'])
    list_Viscera_weight=datosEstadisticos(datos['Viscera weight'])
    list_Shell_weight=datosEstadisticos(datos['Shell weight'])
    list_Rings=datosEstadisticos(datos['Rings'])
    
    #--------------------------------titulo---------------------------------------
    ventana_2 = tk.Tk()
    ventana_2.title("Data analytics and artificial intelligence")
    
    label_1 = tk.Label(ventana_2,text="Columm's Name",
                              fg="blue",
                              font="consolas 12 bold",borderwidth=3)
    label_1.grid(padx=10, pady=10, row=1, column=0,)
    
    label_2 = tk.Label(ventana_2,text="Longitud",
                              fg="blue",
                              font="consolas 12 bold",borderwidth=3)
    label_2.grid(padx=10, pady=10, row=2, column=0, )
    
    label_3 = tk.Label(ventana_2,text="Diametro",
                              fg="blue",
                              font="consolas 12 bold",borderwidth=3)
    label_3.grid(padx=10, pady=10, row=3, column=0, )
    
    label_4 = tk.Label(ventana_2,text="Altura",
                              fg="blue",
                              font="consolas 12 bold",borderwidth=3)
    label_4.grid(padx=10, pady=10, row=4, column=0, )
    
    label_5 = tk.Label(ventana_2,text="Peso entero",
                              fg="blue",
                              font="consolas 12 bold",borderwidth=3)
    label_5.grid(padx=10, pady=10, row=5, column=0, )
    
    label_6 = tk.Label(ventana_2,text="Peso desbullado",
                              fg="blue",
                              font="consolas 12 bold",borderwidth=3)
    label_6.grid(padx=10, pady=10, row=6, column=0, )
    
    label_7 = tk.Label(ventana_2,text="Peso de vísceras",
                              fg="blue",
                              font="consolas 12 bold",borderwidth=3)
    label_7.grid(padx=10, pady=10, row=7, column=0, )
    
    label_8 = tk.Label(ventana_2,text="Peso de la cáscara",
                              fg="blue",
                              font="consolas 12 bold",borderwidth=3)
    label_8.grid(padx=10, pady=10, row=8, column=0, )
    
    label_9 = tk.Label(ventana_2,text="Anillos",
                              fg="blue",
                              font="consolas 12 bold",borderwidth=3)
    label_9.grid(padx=10, pady=10, row=9, column=0, )
    
    
    
    label_10 = tk.Label(ventana_2,text="Mediana",
                              fg="blue",
                              font="consolas 12 bold",)
    label_10.grid(padx=10, pady=10, row=1, column=1, )
    
    label_11 = tk.Label(ventana_2,text="Moda",
                              fg="blue",
                              font="consolas 12 bold",)
    label_11.grid(padx=10, pady=10, row=1, column=2, )
    
    label_12 = tk.Label(ventana_2,text="Media",
                              fg="blue",
                              font="consolas 12 bold",)
    label_12.grid(padx=10, pady=10, row=1, column=3, )
    
    label_13 = tk.Label(ventana_2,text="Kurtosis",
                              fg="blue",
                              font="consolas 12 bold",)
    label_13.grid(padx=10, pady=10, row=1, column=4, )
    
    label_14 = tk.Label(ventana_2,text="Skewness",
                              fg="blue",
                              font="consolas 12 bold",)
    label_14.grid(padx=10, pady=10, row=1, column=5, )
    
    len_mean = tk.Label(ventana_2,text=str(list_Length[0]),bg="White",fg="black",font="consolas 14 bold",state="normal").grid(padx=10, pady=10, row=2, column=1)
    len_mode = tk.Label(ventana_2,text=str(list_Length[1]),bg="White",fg="black",font="consolas 14 bold",state="normal").grid(padx=10, pady=10, row=2, column=2)
    len_median = tk.Label(ventana_2,text=str(list_Length[2]),bg="White",fg="black",font="consolas 14 bold",state="normal").grid(padx=10, pady=10, row=2, column=3)
    len_kurtosis = tk.Label(ventana_2,text=str(list_Length[3]),bg="White",fg="black",font="consolas 14 bold",state="normal").grid(padx=10, pady=10, row=2, column=4)
    len_skew = tk.Label(ventana_2,text=str(list_Length[4]),bg="White",fg="black",font="consolas 14 bold",state="normal").grid(padx=10, pady=10, row=2, column=5)
    
    len_mean2 = tk.Label(ventana_2,text=str(list_Diameter[0]),bg="White",fg="black",font="consolas 14 bold",state="normal").grid(padx=10, pady=10, row=3, column=1)
    len_mode2 = tk.Label(ventana_2,text=str(list_Diameter[1]),bg="White",fg="black",font="consolas 14 bold",state="normal").grid(padx=10, pady=10, row=3, column=2)
    len_median2 = tk.Label(ventana_2,text=str(list_Diameter[2]),bg="White",fg="black",font="consolas 14 bold",state="normal").grid(padx=10, pady=10, row=3, column=3)
    len_kurtosis2 = tk.Label(ventana_2,text=str(list_Diameter[3]),bg="White",fg="black",font="consolas 14 bold",state="normal").grid(padx=10, pady=10, row=3, column=4)
    len_skew2 = tk.Label(ventana_2,text=str(list_Diameter[4]),bg="White",fg="black",font="consolas 14 bold",state="normal").grid(padx=10, pady=10, row=3, column=5)
    
    len_mean3 = tk.Label(ventana_2,text=str(list_Height[0]),bg="White",fg="black",font="consolas 14 bold",state="normal").grid(padx=10, pady=10, row=4, column=1)
    len_mode3 = tk.Label(ventana_2,text=str(list_Height[1]),bg="White",fg="black",font="consolas 14 bold",state="normal").grid(padx=10, pady=10, row=4, column=2)
    len_median3 = tk.Label(ventana_2,text=str(list_Height[2]),bg="White",fg="black",font="consolas 14 bold",state="normal").grid(padx=10, pady=10, row=4, column=3)
    len_kurtosis3 = tk.Label(ventana_2,text=str(list_Height[3]),bg="White",fg="black",font="consolas 14 bold",state="normal").grid(padx=10, pady=10, row=4, column=4)
    len_skew3 = tk.Label(ventana_2,text=str(list_Height[4]),bg="White",fg="black",font="consolas 14 bold",state="normal").grid(padx=10, pady=10, row=4, column=5)
    
    len_mean4 = tk.Label(ventana_2,text=str(list_Whole_weight[0]),bg="White",fg="black",font="consolas 14 bold",state="normal").grid(padx=10, pady=10, row=5, column=1)
    len_mode4 = tk.Label(ventana_2,text=str(list_Whole_weight[1]),bg="White",fg="black",font="consolas 14 bold",state="normal").grid(padx=10, pady=10, row=5, column=2)
    len_median4 = tk.Label(ventana_2,text=str(list_Whole_weight[2]),bg="White",fg="black",font="consolas 14 bold",state="normal").grid(padx=10, pady=10, row=5, column=3)
    len_kurtosis4 = tk.Label(ventana_2,text=str(list_Whole_weight[3]),bg="White",fg="black",font="consolas 14 bold",state="normal").grid(padx=10, pady=10, row=5, column=4)
    len_skew4 = tk.Label(ventana_2,text=str(list_Whole_weight[4]),bg="White",fg="black",font="consolas 14 bold",state="normal").grid(padx=10, pady=10, row=5, column=5)
    
    len_mean5 = tk.Label(ventana_2,text=str(list_Shucked_weight[0]),bg="White",fg="black",font="consolas 14 bold",state="normal").grid(padx=10, pady=10, row=6, column=1)
    len_mode5 = tk.Label(ventana_2,text=str(list_Shucked_weight[1]),bg="White",fg="black",font="consolas 14 bold",state="normal").grid(padx=10, pady=10, row=6, column=2)
    len_median5 = tk.Label(ventana_2,text=str(list_Shucked_weight[2]),bg="White",fg="black",font="consolas 14 bold",state="normal").grid(padx=10, pady=10, row=6, column=3)
    len_kurtosis5 = tk.Label(ventana_2,text=str(list_Shucked_weight[3]),bg="White",fg="black",font="consolas 14 bold",state="normal").grid(padx=10, pady=10, row=6, column=4)
    len_skew5 = tk.Label(ventana_2,text=str(list_Shucked_weight[4]),bg="White",fg="black",font="consolas 14 bold",state="normal").grid(padx=10, pady=10, row=6, column=5)
    
    len_mean6 = tk.Label(ventana_2,text=str(list_Viscera_weight[0]),bg="White",fg="black",font="consolas 14 bold",state="normal").grid(padx=10, pady=10, row=7, column=1)
    len_mode6 = tk.Label(ventana_2,text=str(list_Viscera_weight[1]),bg="White",fg="black",font="consolas 14 bold",state="normal").grid(padx=10, pady=10, row=7, column=2)
    len_median6 = tk.Label(ventana_2,text=str(list_Viscera_weight[2]),bg="White",fg="black",font="consolas 14 bold",state="normal").grid(padx=10, pady=10, row=7, column=3)
    len_kurtosis6 = tk.Label(ventana_2,text=str(list_Viscera_weight[3]),bg="White",fg="black",font="consolas 14 bold",state="normal").grid(padx=10, pady=10, row=7, column=4)
    len_skew6 = tk.Label(ventana_2,text=str(list_Viscera_weight[4]),bg="White",fg="black",font="consolas 14 bold",state="normal").grid(padx=10, pady=10, row=7, column=5)
    
    len_mean7 = tk.Label(ventana_2,text=str(list_Shell_weight[0]),bg="White",fg="black",font="consolas 14 bold",state="normal").grid(padx=10, pady=10, row=8, column=1)
    len_mode7 = tk.Label(ventana_2,text=str(list_Shell_weight[1]),bg="White",fg="black",font="consolas 14 bold",state="normal").grid(padx=10, pady=10, row=8, column=2)
    len_median7 = tk.Label(ventana_2,text=str(list_Shell_weight[2]),bg="White",fg="black",font="consolas 14 bold",state="normal").grid(padx=10, pady=10, row=8, column=3)
    len_kurtosis7 = tk.Label(ventana_2,text=str(list_Shell_weight[3]),bg="White",fg="black",font="consolas 14 bold",state="normal").grid(padx=10, pady=10, row=8, column=4)
    len_skew7 = tk.Label(ventana_2,text=str(list_Shell_weight[4]),bg="White",fg="black",font="consolas 14 bold",state="normal").grid(padx=10, pady=10, row=8, column=5)
    
    len_mean8 = tk.Label(ventana_2,text=str(list_Rings[0]),bg="White",fg="black",font="consolas 14 bold",state="normal").grid(padx=10, pady=10, row=9, column=1)
    len_mode8 = tk.Label(ventana_2,text=str(list_Rings[1]),bg="White",fg="black",font="consolas 14 bold",state="normal").grid(padx=10, pady=10, row=9, column=2)
    len_median8 = tk.Label(ventana_2,text=str(list_Rings[2]),bg="White",fg="black",font="consolas 14 bold",state="normal").grid(padx=10, pady=10, row=9, column=3)
    len_kurtosis8 = tk.Label(ventana_2,text=str(list_Rings[3]),bg="White",fg="black",font="consolas 14 bold",state="normal").grid(padx=10, pady=10, row=9, column=4)
    len_skew8 = tk.Label(ventana_2,text=str(list_Rings[4]),bg="White",fg="black",font="consolas 14 bold",state="normal").grid(padx=10, pady=10, row=9, column=5)

#-------------------------------------------------------------------------------------

def hallarAtipicos(datos, columnas):
    valor = 999
    contador = 0;
    Atipicos1 = []
    k = comboDatosConstante.get();
    if(k == ""):
        k = "1.5"
    for i in range(len(datos["Length"])):
        Atipicos1.append(0);
    
    for i in columnas:
        if(i != "Sex"):    
            p1 = np.quantile(datos[i], 0.25)
            u1 = np.quantile(datos[i], 0.75)
            
            RI1 = u1 - p1
            
            Lp11 = p1 - (float(k) * RI1)
            Lp21 = u1 + (float(k) * RI1)
    
            for j in datos[i]:
                if(j<Lp11 or j>Lp21):
                    Atipicos1[contador] = valor
                    contador = contador + 1
            contador = 0
    return Atipicos1

def EliminarDatosAtipicos(datos1, Atipicos):
    contador = 0
    for i in Atipicos:
        if(i == 999):
            datos1 = datos1.drop(index = [contador])
        contador = contador + 1
    return datos1

def show_selection():
    tipo = comboTpGrafica.get()
    columna1 = comboTpDatos1.get()
    columna2 = comboTpDatos2.get()
    salida= comboSalida.get()
    
    atipicos=comboDatosAtipicos.get()
    Atipicos= hallarAtipicos(datos, columnas)
    datos2 = EliminarDatosAtipicos(datos, Atipicos)
    
    if(tipo == "Histograma"):
        if(atipicos == "Si"):        
            Graficar1(datos, columna1)
        else:
            Graficar1(datosclean, columna1)
    elif(tipo == "Cajas y Bigotes"):
        if(atipicos == "Si"):        
            Graficar2(datos, columna1)
        else:
            Graficar2(datosclean, columna1)
    elif(tipo == "Normal"):    
        if(atipicos == "Si"):        
            Graficar3(datos, columna1)
        else:
            Graficar3(datosclean, columna1)
    elif(tipo == "Combinaciones"):
        if(atipicos == "Si"):        
            Graficar4(datos, columna1, columna2)
    elif(tipo == "Tabla Estadistica"):
        if(atipicos == "Si"):        
            Graficar6(datos)
        else:
            Graficar6(datos2)
    elif(tipo == "Regresion"):
        columna1 = comboTpDatos1Reg.get()
        columna2 = comboTpDatos2Reg.get()
        columna3= comboTpDatos3Reg.get()
        columna4= comboTpDatos4Reg.get()
        columna5= comboTpDatos5Reg.get()
        columna6= comboTpDatos6Reg.get()
        columna7= comboTpDatos7Reg.get()
        columna8= comboTpDatos8Reg.get()
        if(atipicos == "Si"):        
            Graficar5(datos, R1, R2, R3, R4, R5, R6, R7, R8, SALIDA, N)
        else:
            Graficar5(datos2, R1, R2, R3, R4, R5, R6, R7, R8, SALIDA, N)


main_window.config(width=1200, height=700)
main_window.title("Proyecto")
main_window.resizable(width = False, height = False)
fondo = tk.PhotoImage(file= "img6.png")
fondo1 = tk.Label(main_window, image=fondo).place(x=0, y=0, relwidth=1, relheight=1)




#------------------Seleccionar el tipo de grafica--------------------------------

def selectionDatos(event):
    
    selection = comboTpGrafica.get()
    if(selection == "Combinaciones"):
        comboTpDatos2["values"]=['Length', 'Diameter', 'Height', 'Whole weight', 'Shucked weight', 'Viscera weight', 'Shell weight', 'Rings']
    else:
        comboTpDatos2["values"]=[]
        
    if(selection != "Regresion"):
        comboTpDatos1["values"]=['Length', 'Diameter', 'Height', 'Whole weight', 'Shucked weight', 'Viscera weight', 'Shell weight', 'Rings']
        comboDatosAtipicos["values"]=["Si","No"]
        comboDatosConstante["values"]=["1.5","2","2.5","3","3.5","4"]
    else:
        comboTpDatos1["values"]=[]
        comboDatosAtipicos["values"]=[]
        comboDatosConstante["values"]=[]
    if(selection!="Tabla Estadistica"):
        comboTpDatos1["values"]=['Length', 'Diameter', 'Height', 'Whole weight', 'Shucked weight', 'Viscera weight', 'Shell weight', 'Rings']
        comboDatosAtipicos["values"]=["Si","No"]
        comboDatosConstante["values"]=["1.5","2","2.5","3","3.5","4"]
    else:
        comboTpDatos1["values"]=[]
        comboDatosConstante["values"]=[]
        
        
        

#----------------------------ComboBox tipo grafica-------------------------------

comboTpGrafica = ttk.Combobox(values=["Cajas y Bigotes", "Histograma", "Normal", "Regresion", "Combinaciones", "Tabla Estadistica"])
comboTpGrafica.bind("<<ComboboxSelected>>", selectionDatos)
comboTpGrafica.place(x=10, y=160)
comboTpGrafica.configure(width=20, height=10)

#----------------------------Seleccionar las variables---------------------------
comboTpDatos1 = ttk.Combobox(state="readonly",values=[])
comboTpDatos1.place(x=10, y=280)
comboTpDatos1.configure(width=20, height=10)

comboTpDatos2 = ttk.Combobox(state="readonly",values=[])
comboTpDatos2.place(x=10, y=380)
comboTpDatos2.configure(width=20, height=10)
    
comboDatosAtipicos = ttk.Combobox(state="readonly",values=[])
comboDatosAtipicos.place(x=10, y=500)
comboDatosAtipicos.configure(width=20, height=10)
    
comboDatosConstante = ttk.Combobox(state="readonly",values=[])
comboDatosConstante.place(x=250, y=500)
comboDatosConstante.configure(width=20, height=10)

button = tk.Button(command=show_selection, width= 34, height=3, text="Graficar")
button.place(x=90, y=560)

#-------------------------------------Regresion comboBox-----------------------------

#1
comboTpDatos1Reg = ttk.Combobox(state="readonly",
values=['Length', 'Diameter', 'Height', 'Whole weight', 'Shucked weight', 'Viscera weight', 'Shell weight', 'Rings'])
comboTpDatos1Reg.place(x=510, y=180)
comboTpDatos1Reg.configure(width=20, height=10)

#2
comboTpDatos2Reg = ttk.Combobox(state="readonly",
values=['Length', 'Diameter', 'Height', 'Whole weight', 'Shucked weight', 'Viscera weight', 'Shell weight', 'Rings'])
comboTpDatos2Reg.place(x=510, y=235)
comboTpDatos2Reg.configure(width=20, height=10)

#3
comboTpDatos3Reg = ttk.Combobox(state="readonly",
values=['Length', 'Diameter', 'Height', 'Whole weight', 'Shucked weight', 'Viscera weight', 'Shell weight', 'Rings'])
comboTpDatos3Reg.place(x=510, y=295)
comboTpDatos3Reg.configure(width=20, height=10)

#4
comboTpDatos4Reg = ttk.Combobox(state="readonly",
values=['Length', 'Diameter', 'Height', 'Whole weight', 'Shucked weight', 'Viscera weight', 'Shell weight', 'Rings'])
comboTpDatos4Reg.place(x=510, y=350)
comboTpDatos4Reg.configure(width=20, height=10)

#5
comboTpDatos5Reg = ttk.Combobox(state="readonly",
values=['Length', 'Diameter', 'Height', 'Whole weight', 'Shucked weight', 'Viscera weight', 'Shell weight', 'Rings'])
comboTpDatos5Reg.place(x=510, y=405)
comboTpDatos5Reg.configure(width=20, height=10)

#6
comboTpDatos6Reg = ttk.Combobox(state="readonly",
values=['Length', 'Diameter', 'Height', 'Whole weight', 'Shucked weight', 'Viscera weight', 'Shell weight', 'Rings'])
comboTpDatos6Reg.place(x=510, y=465)
comboTpDatos6Reg.configure(width=20, height=10)

#7
comboTpDatos7Reg = ttk.Combobox(state="readonly",
values=['Length', 'Diameter', 'Height', 'Whole weight', 'Shucked weight', 'Viscera weight', 'Shell weight', 'Rings'])
comboTpDatos7Reg.place(x=510, y=520)
comboTpDatos7Reg.configure(width=20, height=10)

#8
comboTpDatos8Reg = ttk.Combobox(state="readonly",
values=['Length', 'Diameter', 'Height', 'Whole weight', 'Shucked weight', 'Viscera weight', 'Shell weight', 'Rings'])
comboTpDatos8Reg.place(x=510, y=580)
comboTpDatos8Reg.configure(width=20, height=10)

#9
comboSalida = ttk.Combobox(state="readonly",
values=['Length', 'Diameter', 'Height', 'Whole weight', 'Shucked weight', 'Viscera weight', 'Shell weight', 'Rings'])
comboSalida.place(x=810, y=235)
comboSalida.configure(width=20, height=10)


main_window.mainloop()






