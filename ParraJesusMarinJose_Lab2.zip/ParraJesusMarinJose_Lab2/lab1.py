import pandas as pd
import matplotlib.pyplot as plot
from scipy import stats
import numpy  as np

archivo='abalone.csv'
datos=pd.read_csv(archivo)
#Insertamos las columnas de la talba excel
columnas=['sex', 'length',
'Diameter',
'Height',
'Whole weight',
'Shucked weight',
'Viscera weight',
'Shell weight',
'Rings' ]
datos.columns=columnas

def graficas1(df, ft):
    plot.hist(df[ft]) #Primera Grafica histograma
    plot.subplots() #Segunda Grafica cajas y bigotes
    plot.boxplot(df[ft])
    fig=plot.figure() #Tercera grafica normal
    ax=fig.add_subplot(111) #Cantidad de graficas
    res=stats.probplot(df[ft],dist=stats.norm,plot=ax)
    plot.subplots()

for i in ['length', 'Diameter', 'Height', 'Whole weight', 'Shucked weight', 'Viscera weight', 'Shell weight', 'Rings']:
    graficas1(datos, i)

def remove_atipicos(df, ft):
    q1 = df[ft].quantile(0.25)
    q3 = df[ft].quantile(0.75)
    iqr = q3-q1 #Interquartile range
    low  = q1-1.5*iqr
    high = q3+1.5*iqr
    ls = df.index[ (df[ft] < low) | (df[ft] > high) ]
    return ls

index_list = []
for i in ['length', 'Diameter', 'Height', 'Whole weight', 'Shucked weight', 'Viscera weight', 'Shell weight', 'Rings']:
    index_list.extend(remove_atipicos(datos, i))

def remove(df, ls):
    ls = sorted(set(ls))
    df = df.drop(ls)
    return df

datosclean = remove(datos, index_list)
for i in ['length', 'Diameter', 'Height', 'Whole weight', 'Shucked weight', 'Viscera weight', 'Shell weight', 'Rings']:
    graficas1(datosclean, i)